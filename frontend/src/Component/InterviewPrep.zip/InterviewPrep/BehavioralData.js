const behavioralData = [
  {
    "id": "subject-1",
    "title": "Self-Introduction",
    "topics": [
      {
        "id": "topic-1",
        "title": "Tell Me About Yourself",
        "expanded": false,
        "resources": [
          {
            "id": "resource-1",
            "title": "Tell Me About Yourself - Insight 1",
            "article": "https://example.com/articles/tell_me_about_yourself/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-2",
            "title": "Tell Me About Yourself - Insight 2",
            "article": "https://example.com/articles/tell_me_about_yourself/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-3",
            "title": "Tell Me About Yourself - Insight 3",
            "article": "https://example.com/articles/tell_me_about_yourself/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-2",
        "title": "Describe Yourself in 3 Words",
        "expanded": false,
        "resources": [
          {
            "id": "resource-4",
            "title": "Describe Yourself in 3 Words - Insight 1",
            "article": "https://example.com/articles/describe_yourself_in_3_words/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-5",
            "title": "Describe Yourself in 3 Words - Insight 2",
            "article": "https://example.com/articles/describe_yourself_in_3_words/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-6",
            "title": "Describe Yourself in 3 Words - Insight 3",
            "article": "https://example.com/articles/describe_yourself_in_3_words/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-3",
        "title": "What Are Your Hobbies?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-7",
            "title": "What Are Your Hobbies? - Insight 1",
            "article": "https://example.com/articles/what_are_your_hobbies?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-8",
            "title": "What Are Your Hobbies? - Insight 2",
            "article": "https://example.com/articles/what_are_your_hobbies?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-9",
            "title": "What Are Your Hobbies? - Insight 3",
            "article": "https://example.com/articles/what_are_your_hobbies?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-4",
        "title": "Walk Me Through Your Resume",
        "expanded": false,
        "resources": [
          {
            "id": "resource-10",
            "title": "Walk Me Through Your Resume - Insight 1",
            "article": "https://example.com/articles/walk_me_through_your_resume/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-11",
            "title": "Walk Me Through Your Resume - Insight 2",
            "article": "https://example.com/articles/walk_me_through_your_resume/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-12",
            "title": "Walk Me Through Your Resume - Insight 3",
            "article": "https://example.com/articles/walk_me_through_your_resume/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-2",
    "title": "Strengths and Weaknesses",
    "topics": [
      {
        "id": "topic-5",
        "title": "What Are Your Strengths?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-13",
            "title": "What Are Your Strengths? - Insight 1",
            "article": "https://example.com/articles/what_are_your_strengths?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-14",
            "title": "What Are Your Strengths? - Insight 2",
            "article": "https://example.com/articles/what_are_your_strengths?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-15",
            "title": "What Are Your Strengths? - Insight 3",
            "article": "https://example.com/articles/what_are_your_strengths?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-6",
        "title": "What Is Your Biggest Weakness?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-16",
            "title": "What Is Your Biggest Weakness? - Insight 1",
            "article": "https://example.com/articles/what_is_your_biggest_weakness?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-17",
            "title": "What Is Your Biggest Weakness? - Insight 2",
            "article": "https://example.com/articles/what_is_your_biggest_weakness?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-18",
            "title": "What Is Your Biggest Weakness? - Insight 3",
            "article": "https://example.com/articles/what_is_your_biggest_weakness?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-7",
        "title": "How Do You Handle Criticism?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-19",
            "title": "How Do You Handle Criticism? - Insight 1",
            "article": "https://example.com/articles/how_do_you_handle_criticism?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-20",
            "title": "How Do You Handle Criticism? - Insight 2",
            "article": "https://example.com/articles/how_do_you_handle_criticism?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-21",
            "title": "How Do You Handle Criticism? - Insight 3",
            "article": "https://example.com/articles/how_do_you_handle_criticism?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-8",
        "title": "What Would Your Friends Say About You?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-22",
            "title": "What Would Your Friends Say About You? - Insight 1",
            "article": "https://example.com/articles/what_would_your_friends_say_about_you?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-23",
            "title": "What Would Your Friends Say About You? - Insight 2",
            "article": "https://example.com/articles/what_would_your_friends_say_about_you?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-24",
            "title": "What Would Your Friends Say About You? - Insight 3",
            "article": "https://example.com/articles/what_would_your_friends_say_about_you?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-3",
    "title": "Teamwork and Leadership",
    "topics": [
      {
        "id": "topic-9",
        "title": "Describe a Team Project",
        "expanded": false,
        "resources": [
          {
            "id": "resource-25",
            "title": "Describe a Team Project - Insight 1",
            "article": "https://example.com/articles/describe_a_team_project/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-26",
            "title": "Describe a Team Project - Insight 2",
            "article": "https://example.com/articles/describe_a_team_project/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-27",
            "title": "Describe a Team Project - Insight 3",
            "article": "https://example.com/articles/describe_a_team_project/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-10",
        "title": "How Do You Handle Conflict in a Team?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-28",
            "title": "How Do You Handle Conflict in a Team? - Insight 1",
            "article": "https://example.com/articles/how_do_you_handle_conflict_in_a_team?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-29",
            "title": "How Do You Handle Conflict in a Team? - Insight 2",
            "article": "https://example.com/articles/how_do_you_handle_conflict_in_a_team?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-30",
            "title": "How Do You Handle Conflict in a Team? - Insight 3",
            "article": "https://example.com/articles/how_do_you_handle_conflict_in_a_team?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-11",
        "title": "Tell Me About a Time You Led a Team",
        "expanded": false,
        "resources": [
          {
            "id": "resource-31",
            "title": "Tell Me About a Time You Led a Team - Insight 1",
            "article": "https://example.com/articles/tell_me_about_a_time_you_led_a_team/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-32",
            "title": "Tell Me About a Time You Led a Team - Insight 2",
            "article": "https://example.com/articles/tell_me_about_a_time_you_led_a_team/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-33",
            "title": "Tell Me About a Time You Led a Team - Insight 3",
            "article": "https://example.com/articles/tell_me_about_a_time_you_led_a_team/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-12",
        "title": "How Do You Motivate Others?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-34",
            "title": "How Do You Motivate Others? - Insight 1",
            "article": "https://example.com/articles/how_do_you_motivate_others?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-35",
            "title": "How Do You Motivate Others? - Insight 2",
            "article": "https://example.com/articles/how_do_you_motivate_others?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-36",
            "title": "How Do You Motivate Others? - Insight 3",
            "article": "https://example.com/articles/how_do_you_motivate_others?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-4",
    "title": "Time and Stress Management",
    "topics": [
      {
        "id": "topic-13",
        "title": "Describe a Time You Worked Under Pressure",
        "expanded": false,
        "resources": [
          {
            "id": "resource-37",
            "title": "Describe a Time You Worked Under Pressure - Insight 1",
            "article": "https://example.com/articles/describe_a_time_you_worked_under_pressure/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-38",
            "title": "Describe a Time You Worked Under Pressure - Insight 2",
            "article": "https://example.com/articles/describe_a_time_you_worked_under_pressure/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-39",
            "title": "Describe a Time You Worked Under Pressure - Insight 3",
            "article": "https://example.com/articles/describe_a_time_you_worked_under_pressure/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-14",
        "title": "How Do You Manage Deadlines?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-40",
            "title": "How Do You Manage Deadlines? - Insight 1",
            "article": "https://example.com/articles/how_do_you_manage_deadlines?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-41",
            "title": "How Do You Manage Deadlines? - Insight 2",
            "article": "https://example.com/articles/how_do_you_manage_deadlines?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-42",
            "title": "How Do You Manage Deadlines? - Insight 3",
            "article": "https://example.com/articles/how_do_you_manage_deadlines?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-15",
        "title": "Describe a Challenge and How You Overcame It",
        "expanded": false,
        "resources": [
          {
            "id": "resource-43",
            "title": "Describe a Challenge and How You Overcame It - Insight 1",
            "article": "https://example.com/articles/describe_a_challenge_and_how_you_overcame_it/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-44",
            "title": "Describe a Challenge and How You Overcame It - Insight 2",
            "article": "https://example.com/articles/describe_a_challenge_and_how_you_overcame_it/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-45",
            "title": "Describe a Challenge and How You Overcame It - Insight 3",
            "article": "https://example.com/articles/describe_a_challenge_and_how_you_overcame_it/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-16",
        "title": "How Do You Prioritize Tasks?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-46",
            "title": "How Do You Prioritize Tasks? - Insight 1",
            "article": "https://example.com/articles/how_do_you_prioritize_tasks?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-47",
            "title": "How Do You Prioritize Tasks? - Insight 2",
            "article": "https://example.com/articles/how_do_you_prioritize_tasks?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-48",
            "title": "How Do You Prioritize Tasks? - Insight 3",
            "article": "https://example.com/articles/how_do_you_prioritize_tasks?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-5",
    "title": "Company and Role Fit",
    "topics": [
      {
        "id": "topic-17",
        "title": "Why Do You Want to Work Here?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-49",
            "title": "Why Do You Want to Work Here? - Insight 1",
            "article": "https://example.com/articles/why_do_you_want_to_work_here?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-50",
            "title": "Why Do You Want to Work Here? - Insight 2",
            "article": "https://example.com/articles/why_do_you_want_to_work_here?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-51",
            "title": "Why Do You Want to Work Here? - Insight 3",
            "article": "https://example.com/articles/why_do_you_want_to_work_here?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-18",
        "title": "What Are Your Career Goals?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-52",
            "title": "What Are Your Career Goals? - Insight 1",
            "article": "https://example.com/articles/what_are_your_career_goals?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-53",
            "title": "What Are Your Career Goals? - Insight 2",
            "article": "https://example.com/articles/what_are_your_career_goals?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-54",
            "title": "What Are Your Career Goals? - Insight 3",
            "article": "https://example.com/articles/what_are_your_career_goals?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-19",
        "title": "Why Should We Hire You?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-55",
            "title": "Why Should We Hire You? - Insight 1",
            "article": "https://example.com/articles/why_should_we_hire_you?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-56",
            "title": "Why Should We Hire You? - Insight 2",
            "article": "https://example.com/articles/why_should_we_hire_you?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-57",
            "title": "Why Should We Hire You? - Insight 3",
            "article": "https://example.com/articles/why_should_we_hire_you?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-20",
        "title": "What Do You Know About This Role?",
        "expanded": false,
        "resources": [
          {
            "id": "resource-58",
            "title": "What Do You Know About This Role? - Insight 1",
            "article": "https://example.com/articles/what_do_you_know_about_this_role?/1",
            "youtube": "https://youtube.com/watch?v=behavior1",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-59",
            "title": "What Do You Know About This Role? - Insight 2",
            "article": "https://example.com/articles/what_do_you_know_about_this_role?/2",
            "youtube": "https://youtube.com/watch?v=behavior2",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-60",
            "title": "What Do You Know About This Role? - Insight 3",
            "article": "https://example.com/articles/what_do_you_know_about_this_role?/3",
            "youtube": "https://youtube.com/watch?v=behavior3",
            "practice": "https://www.pramp.com/",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  }
];

export default behavioralData;