const interviewData = [
  {
    "id": "subject-1",
    "title": "DBMS",
    "topics": [
      {
        "id": "topic-1",
        "title": "SQL Queries",
        "expanded": false,
        "resources": [
          {
            "id": "resource-1",
            "title": "SQL Queries - Problem 3",
            "article": "https://example.com/articles/sql_queries/3",
            "youtube": "https://youtube.com/watch?v=video4",
            "practice": "https://leetcode.com/problemset/all/?topic=sqlqueries",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-2",
            "title": "SQL Queries - Problem 4",
            "article": "https://example.com/articles/sql_queries/4",
            "youtube": "https://youtube.com/watch?v=video5",
            "practice": "https://leetcode.com/problemset/all/?topic=sqlqueries",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-3",
            "title": "SQL Queries - Problem 5",
            "article": "https://example.com/articles/sql_queries/5",
            "youtube": "https://youtube.com/watch?v=video6",
            "practice": "https://leetcode.com/problemset/all/?topic=sqlqueries",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-2",
        "title": "Normalization",
        "expanded": false,
        "resources": [
          {
            "id": "resource-4",
            "title": "Normalization - Problem 3",
            "article": "https://example.com/articles/normalization/3",
            "youtube": "https://youtube.com/watch?v=video7",
            "practice": "https://leetcode.com/problemset/all/?topic=normalization",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-5",
            "title": "Normalization - Problem 4",
            "article": "https://example.com/articles/normalization/4",
            "youtube": "https://youtube.com/watch?v=video8",
            "practice": "https://leetcode.com/problemset/all/?topic=normalization",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-6",
            "title": "Normalization - Problem 5",
            "article": "https://example.com/articles/normalization/5",
            "youtube": "https://youtube.com/watch?v=video9",
            "practice": "https://leetcode.com/problemset/all/?topic=normalization",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-3",
        "title": "Transactions",
        "expanded": false,
        "resources": [
          {
            "id": "resource-7",
            "title": "Transactions - Problem 3",
            "article": "https://example.com/articles/transactions/3",
            "youtube": "https://youtube.com/watch?v=video10",
            "practice": "https://leetcode.com/problemset/all/?topic=transactions",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-8",
            "title": "Transactions - Problem 4",
            "article": "https://example.com/articles/transactions/4",
            "youtube": "https://youtube.com/watch?v=video11",
            "practice": "https://leetcode.com/problemset/all/?topic=transactions",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-9",
            "title": "Transactions - Problem 5",
            "article": "https://example.com/articles/transactions/5",
            "youtube": "https://youtube.com/watch?v=video12",
            "practice": "https://leetcode.com/problemset/all/?topic=transactions",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-4",
        "title": "Indexing",
        "expanded": false,
        "resources": [
          {
            "id": "resource-10",
            "title": "Indexing - Problem 3",
            "article": "https://example.com/articles/indexing/3",
            "youtube": "https://youtube.com/watch?v=video13",
            "practice": "https://leetcode.com/problemset/all/?topic=indexing",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-11",
            "title": "Indexing - Problem 4",
            "article": "https://example.com/articles/indexing/4",
            "youtube": "https://youtube.com/watch?v=video14",
            "practice": "https://leetcode.com/problemset/all/?topic=indexing",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-12",
            "title": "Indexing - Problem 5",
            "article": "https://example.com/articles/indexing/5",
            "youtube": "https://youtube.com/watch?v=video15",
            "practice": "https://leetcode.com/problemset/all/?topic=indexing",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-2",
    "title": "Operating Systems",
    "topics": [
      {
        "id": "topic-5",
        "title": "Process Management",
        "expanded": false,
        "resources": [
          {
            "id": "resource-13",
            "title": "Process Management - Problem 3",
            "article": "https://example.com/articles/process_management/3",
            "youtube": "https://youtube.com/watch?v=video16",
            "practice": "https://leetcode.com/problemset/all/?topic=processmanagement",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-14",
            "title": "Process Management - Problem 4",
            "article": "https://example.com/articles/process_management/4",
            "youtube": "https://youtube.com/watch?v=video17",
            "practice": "https://leetcode.com/problemset/all/?topic=processmanagement",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-15",
            "title": "Process Management - Problem 5",
            "article": "https://example.com/articles/process_management/5",
            "youtube": "https://youtube.com/watch?v=video18",
            "practice": "https://leetcode.com/problemset/all/?topic=processmanagement",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-6",
        "title": "Memory Management",
        "expanded": false,
        "resources": [
          {
            "id": "resource-16",
            "title": "Memory Management - Problem 3",
            "article": "https://example.com/articles/memory_management/3",
            "youtube": "https://youtube.com/watch?v=video19",
            "practice": "https://leetcode.com/problemset/all/?topic=memorymanagement",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-17",
            "title": "Memory Management - Problem 4",
            "article": "https://example.com/articles/memory_management/4",
            "youtube": "https://youtube.com/watch?v=video20",
            "practice": "https://leetcode.com/problemset/all/?topic=memorymanagement",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-18",
            "title": "Memory Management - Problem 5",
            "article": "https://example.com/articles/memory_management/5",
            "youtube": "https://youtube.com/watch?v=video21",
            "practice": "https://leetcode.com/problemset/all/?topic=memorymanagement",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-7",
        "title": "File Systems",
        "expanded": false,
        "resources": [
          {
            "id": "resource-19",
            "title": "File Systems - Problem 3",
            "article": "https://example.com/articles/file_systems/3",
            "youtube": "https://youtube.com/watch?v=video22",
            "practice": "https://leetcode.com/problemset/all/?topic=filesystems",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-20",
            "title": "File Systems - Problem 4",
            "article": "https://example.com/articles/file_systems/4",
            "youtube": "https://youtube.com/watch?v=video23",
            "practice": "https://leetcode.com/problemset/all/?topic=filesystems",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-21",
            "title": "File Systems - Problem 5",
            "article": "https://example.com/articles/file_systems/5",
            "youtube": "https://youtube.com/watch?v=video24",
            "practice": "https://leetcode.com/problemset/all/?topic=filesystems",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-8",
        "title": "CPU Scheduling",
        "expanded": false,
        "resources": [
          {
            "id": "resource-22",
            "title": "CPU Scheduling - Problem 3",
            "article": "https://example.com/articles/cpu_scheduling/3",
            "youtube": "https://youtube.com/watch?v=video25",
            "practice": "https://leetcode.com/problemset/all/?topic=cpuscheduling",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-23",
            "title": "CPU Scheduling - Problem 4",
            "article": "https://example.com/articles/cpu_scheduling/4",
            "youtube": "https://youtube.com/watch?v=video26",
            "practice": "https://leetcode.com/problemset/all/?topic=cpuscheduling",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-24",
            "title": "CPU Scheduling - Problem 5",
            "article": "https://example.com/articles/cpu_scheduling/5",
            "youtube": "https://youtube.com/watch?v=video27",
            "practice": "https://leetcode.com/problemset/all/?topic=cpuscheduling",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-3",
    "title": "Computer Networks",
    "topics": [
      {
        "id": "topic-9",
        "title": "OSI Model",
        "expanded": false,
        "resources": [
          {
            "id": "resource-25",
            "title": "OSI Model - Problem 3",
            "article": "https://example.com/articles/osi_model/3",
            "youtube": "https://youtube.com/watch?v=video28",
            "practice": "https://leetcode.com/problemset/all/?topic=osimodel",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-26",
            "title": "OSI Model - Problem 4",
            "article": "https://example.com/articles/osi_model/4",
            "youtube": "https://youtube.com/watch?v=video29",
            "practice": "https://leetcode.com/problemset/all/?topic=osimodel",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-27",
            "title": "OSI Model - Problem 5",
            "article": "https://example.com/articles/osi_model/5",
            "youtube": "https://youtube.com/watch?v=video30",
            "practice": "https://leetcode.com/problemset/all/?topic=osimodel",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-10",
        "title": "TCP/IP Protocol",
        "expanded": false,
        "resources": [
          {
            "id": "resource-28",
            "title": "TCP/IP Protocol - Problem 3",
            "article": "https://example.com/articles/tcp/ip_protocol/3",
            "youtube": "https://youtube.com/watch?v=video31",
            "practice": "https://leetcode.com/problemset/all/?topic=tcp/ipprotocol",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-29",
            "title": "TCP/IP Protocol - Problem 4",
            "article": "https://example.com/articles/tcp/ip_protocol/4",
            "youtube": "https://youtube.com/watch?v=video32",
            "practice": "https://leetcode.com/problemset/all/?topic=tcp/ipprotocol",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-30",
            "title": "TCP/IP Protocol - Problem 5",
            "article": "https://example.com/articles/tcp/ip_protocol/5",
            "youtube": "https://youtube.com/watch?v=video33",
            "practice": "https://leetcode.com/problemset/all/?topic=tcp/ipprotocol",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-11",
        "title": "Routing",
        "expanded": false,
        "resources": [
          {
            "id": "resource-31",
            "title": "Routing - Problem 3",
            "article": "https://example.com/articles/routing/3",
            "youtube": "https://youtube.com/watch?v=video34",
            "practice": "https://leetcode.com/problemset/all/?topic=routing",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-32",
            "title": "Routing - Problem 4",
            "article": "https://example.com/articles/routing/4",
            "youtube": "https://youtube.com/watch?v=video35",
            "practice": "https://leetcode.com/problemset/all/?topic=routing",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-33",
            "title": "Routing - Problem 5",
            "article": "https://example.com/articles/routing/5",
            "youtube": "https://youtube.com/watch?v=video36",
            "practice": "https://leetcode.com/problemset/all/?topic=routing",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-12",
        "title": "DNS & HTTP",
        "expanded": false,
        "resources": [
          {
            "id": "resource-34",
            "title": "DNS & HTTP - Problem 3",
            "article": "https://example.com/articles/dns_&_http/3",
            "youtube": "https://youtube.com/watch?v=video37",
            "practice": "https://leetcode.com/problemset/all/?topic=dns&http",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-35",
            "title": "DNS & HTTP - Problem 4",
            "article": "https://example.com/articles/dns_&_http/4",
            "youtube": "https://youtube.com/watch?v=video38",
            "practice": "https://leetcode.com/problemset/all/?topic=dns&http",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-36",
            "title": "DNS & HTTP - Problem 5",
            "article": "https://example.com/articles/dns_&_http/5",
            "youtube": "https://youtube.com/watch?v=video39",
            "practice": "https://leetcode.com/problemset/all/?topic=dns&http",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-4",
    "title": "Java",
    "topics": [
      {
        "id": "topic-13",
        "title": "OOP Concepts",
        "expanded": false,
        "resources": [
          {
            "id": "resource-37",
            "title": "OOP Concepts - Problem 3",
            "article": "https://example.com/articles/oop_concepts/3",
            "youtube": "https://youtube.com/watch?v=video40",
            "practice": "https://leetcode.com/problemset/all/?topic=oopconcepts",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-38",
            "title": "OOP Concepts - Problem 4",
            "article": "https://example.com/articles/oop_concepts/4",
            "youtube": "https://youtube.com/watch?v=video41",
            "practice": "https://leetcode.com/problemset/all/?topic=oopconcepts",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-39",
            "title": "OOP Concepts - Problem 5",
            "article": "https://example.com/articles/oop_concepts/5",
            "youtube": "https://youtube.com/watch?v=video42",
            "practice": "https://leetcode.com/problemset/all/?topic=oopconcepts",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-14",
        "title": "Exception Handling",
        "expanded": false,
        "resources": [
          {
            "id": "resource-40",
            "title": "Exception Handling - Problem 3",
            "article": "https://example.com/articles/exception_handling/3",
            "youtube": "https://youtube.com/watch?v=video43",
            "practice": "https://leetcode.com/problemset/all/?topic=exceptionhandling",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-41",
            "title": "Exception Handling - Problem 4",
            "article": "https://example.com/articles/exception_handling/4",
            "youtube": "https://youtube.com/watch?v=video44",
            "practice": "https://leetcode.com/problemset/all/?topic=exceptionhandling",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-42",
            "title": "Exception Handling - Problem 5",
            "article": "https://example.com/articles/exception_handling/5",
            "youtube": "https://youtube.com/watch?v=video45",
            "practice": "https://leetcode.com/problemset/all/?topic=exceptionhandling",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-15",
        "title": "Collections",
        "expanded": false,
        "resources": [
          {
            "id": "resource-43",
            "title": "Collections - Problem 3",
            "article": "https://example.com/articles/collections/3",
            "youtube": "https://youtube.com/watch?v=video46",
            "practice": "https://leetcode.com/problemset/all/?topic=collections",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-44",
            "title": "Collections - Problem 4",
            "article": "https://example.com/articles/collections/4",
            "youtube": "https://youtube.com/watch?v=video47",
            "practice": "https://leetcode.com/problemset/all/?topic=collections",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-45",
            "title": "Collections - Problem 5",
            "article": "https://example.com/articles/collections/5",
            "youtube": "https://youtube.com/watch?v=video48",
            "practice": "https://leetcode.com/problemset/all/?topic=collections",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-16",
        "title": "Multithreading",
        "expanded": false,
        "resources": [
          {
            "id": "resource-46",
            "title": "Multithreading - Problem 3",
            "article": "https://example.com/articles/multithreading/3",
            "youtube": "https://youtube.com/watch?v=video49",
            "practice": "https://leetcode.com/problemset/all/?topic=multithreading",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-47",
            "title": "Multithreading - Problem 4",
            "article": "https://example.com/articles/multithreading/4",
            "youtube": "https://youtube.com/watch?v=video50",
            "practice": "https://leetcode.com/problemset/all/?topic=multithreading",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-48",
            "title": "Multithreading - Problem 5",
            "article": "https://example.com/articles/multithreading/5",
            "youtube": "https://youtube.com/watch?v=video51",
            "practice": "https://leetcode.com/problemset/all/?topic=multithreading",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-5",
    "title": "C++",
    "topics": [
      {
        "id": "topic-17",
        "title": "STL",
        "expanded": false,
        "resources": [
          {
            "id": "resource-49",
            "title": "STL - Problem 3",
            "article": "https://example.com/articles/stl/3",
            "youtube": "https://youtube.com/watch?v=video52",
            "practice": "https://leetcode.com/problemset/all/?topic=stl",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-50",
            "title": "STL - Problem 4",
            "article": "https://example.com/articles/stl/4",
            "youtube": "https://youtube.com/watch?v=video53",
            "practice": "https://leetcode.com/problemset/all/?topic=stl",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-51",
            "title": "STL - Problem 5",
            "article": "https://example.com/articles/stl/5",
            "youtube": "https://youtube.com/watch?v=video54",
            "practice": "https://leetcode.com/problemset/all/?topic=stl",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-18",
        "title": "Inheritance",
        "expanded": false,
        "resources": [
          {
            "id": "resource-52",
            "title": "Inheritance - Problem 3",
            "article": "https://example.com/articles/inheritance/3",
            "youtube": "https://youtube.com/watch?v=video55",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-53",
            "title": "Inheritance - Problem 4",
            "article": "https://example.com/articles/inheritance/4",
            "youtube": "https://youtube.com/watch?v=video56",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-54",
            "title": "Inheritance - Problem 5",
            "article": "https://example.com/articles/inheritance/5",
            "youtube": "https://youtube.com/watch?v=video57",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-19",
        "title": "Pointers",
        "expanded": false,
        "resources": [
          {
            "id": "resource-55",
            "title": "Pointers - Problem 3",
            "article": "https://example.com/articles/pointers/3",
            "youtube": "https://youtube.com/watch?v=video58",
            "practice": "https://leetcode.com/problemset/all/?topic=pointers",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-56",
            "title": "Pointers - Problem 4",
            "article": "https://example.com/articles/pointers/4",
            "youtube": "https://youtube.com/watch?v=video59",
            "practice": "https://leetcode.com/problemset/all/?topic=pointers",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-57",
            "title": "Pointers - Problem 5",
            "article": "https://example.com/articles/pointers/5",
            "youtube": "https://youtube.com/watch?v=video60",
            "practice": "https://leetcode.com/problemset/all/?topic=pointers",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-20",
        "title": "File I/O",
        "expanded": false,
        "resources": [
          {
            "id": "resource-58",
            "title": "File I/O - Problem 3",
            "article": "https://example.com/articles/file_i/o/3",
            "youtube": "https://youtube.com/watch?v=video61",
            "practice": "https://leetcode.com/problemset/all/?topic=filei/o",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-59",
            "title": "File I/O - Problem 4",
            "article": "https://example.com/articles/file_i/o/4",
            "youtube": "https://youtube.com/watch?v=video62",
            "practice": "https://leetcode.com/problemset/all/?topic=filei/o",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-60",
            "title": "File I/O - Problem 5",
            "article": "https://example.com/articles/file_i/o/5",
            "youtube": "https://youtube.com/watch?v=video63",
            "practice": "https://leetcode.com/problemset/all/?topic=filei/o",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-6",
    "title": "Python",
    "topics": [
      {
        "id": "topic-21",
        "title": "Data Types",
        "expanded": false,
        "resources": [
          {
            "id": "resource-61",
            "title": "Data Types - Problem 3",
            "article": "https://example.com/articles/data_types/3",
            "youtube": "https://youtube.com/watch?v=video64",
            "practice": "https://leetcode.com/problemset/all/?topic=datatypes",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-62",
            "title": "Data Types - Problem 4",
            "article": "https://example.com/articles/data_types/4",
            "youtube": "https://youtube.com/watch?v=video65",
            "practice": "https://leetcode.com/problemset/all/?topic=datatypes",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-63",
            "title": "Data Types - Problem 5",
            "article": "https://example.com/articles/data_types/5",
            "youtube": "https://youtube.com/watch?v=video66",
            "practice": "https://leetcode.com/problemset/all/?topic=datatypes",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-22",
        "title": "Loops & Conditionals",
        "expanded": false,
        "resources": [
          {
            "id": "resource-64",
            "title": "Loops & Conditionals - Problem 3",
            "article": "https://example.com/articles/loops_&_conditionals/3",
            "youtube": "https://youtube.com/watch?v=video67",
            "practice": "https://leetcode.com/problemset/all/?topic=loops&conditionals",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-65",
            "title": "Loops & Conditionals - Problem 4",
            "article": "https://example.com/articles/loops_&_conditionals/4",
            "youtube": "https://youtube.com/watch?v=video68",
            "practice": "https://leetcode.com/problemset/all/?topic=loops&conditionals",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-66",
            "title": "Loops & Conditionals - Problem 5",
            "article": "https://example.com/articles/loops_&_conditionals/5",
            "youtube": "https://youtube.com/watch?v=video69",
            "practice": "https://leetcode.com/problemset/all/?topic=loops&conditionals",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-23",
        "title": "Functions",
        "expanded": false,
        "resources": [
          {
            "id": "resource-67",
            "title": "Functions - Problem 3",
            "article": "https://example.com/articles/functions/3",
            "youtube": "https://youtube.com/watch?v=video70",
            "practice": "https://leetcode.com/problemset/all/?topic=functions",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-68",
            "title": "Functions - Problem 4",
            "article": "https://example.com/articles/functions/4",
            "youtube": "https://youtube.com/watch?v=video71",
            "practice": "https://leetcode.com/problemset/all/?topic=functions",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-69",
            "title": "Functions - Problem 5",
            "article": "https://example.com/articles/functions/5",
            "youtube": "https://youtube.com/watch?v=video72",
            "practice": "https://leetcode.com/problemset/all/?topic=functions",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-24",
        "title": "Libraries (NumPy, Pandas)",
        "expanded": false,
        "resources": [
          {
            "id": "resource-70",
            "title": "Libraries (NumPy, Pandas) - Problem 3",
            "article": "https://example.com/articles/libraries_(numpy,_pandas)/3",
            "youtube": "https://youtube.com/watch?v=video73",
            "practice": "https://leetcode.com/problemset/all/?topic=libraries(numpy,pandas)",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-71",
            "title": "Libraries (NumPy, Pandas) - Problem 4",
            "article": "https://example.com/articles/libraries_(numpy,_pandas)/4",
            "youtube": "https://youtube.com/watch?v=video74",
            "practice": "https://leetcode.com/problemset/all/?topic=libraries(numpy,pandas)",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-72",
            "title": "Libraries (NumPy, Pandas) - Problem 5",
            "article": "https://example.com/articles/libraries_(numpy,_pandas)/5",
            "youtube": "https://youtube.com/watch?v=video75",
            "practice": "https://leetcode.com/problemset/all/?topic=libraries(numpy,pandas)",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-7",
    "title": "Data Structures",
    "topics": [
      {
        "id": "topic-25",
        "title": "Arrays",
        "expanded": false,
        "resources": [
          {
            "id": "resource-73",
            "title": "Arrays - Problem 3",
            "article": "https://example.com/articles/arrays/3",
            "youtube": "https://youtube.com/watch?v=video76",
            "practice": "https://leetcode.com/problemset/all/?topic=arrays",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-74",
            "title": "Arrays - Problem 4",
            "article": "https://example.com/articles/arrays/4",
            "youtube": "https://youtube.com/watch?v=video77",
            "practice": "https://leetcode.com/problemset/all/?topic=arrays",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-75",
            "title": "Arrays - Problem 5",
            "article": "https://example.com/articles/arrays/5",
            "youtube": "https://youtube.com/watch?v=video78",
            "practice": "https://leetcode.com/problemset/all/?topic=arrays",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-26",
        "title": "Linked Lists",
        "expanded": false,
        "resources": [
          {
            "id": "resource-76",
            "title": "Linked Lists - Problem 3",
            "article": "https://example.com/articles/linked_lists/3",
            "youtube": "https://youtube.com/watch?v=video79",
            "practice": "https://leetcode.com/problemset/all/?topic=linkedlists",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-77",
            "title": "Linked Lists - Problem 4",
            "article": "https://example.com/articles/linked_lists/4",
            "youtube": "https://youtube.com/watch?v=video80",
            "practice": "https://leetcode.com/problemset/all/?topic=linkedlists",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-78",
            "title": "Linked Lists - Problem 5",
            "article": "https://example.com/articles/linked_lists/5",
            "youtube": "https://youtube.com/watch?v=video81",
            "practice": "https://leetcode.com/problemset/all/?topic=linkedlists",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-27",
        "title": "Stacks & Queues",
        "expanded": false,
        "resources": [
          {
            "id": "resource-79",
            "title": "Stacks & Queues - Problem 3",
            "article": "https://example.com/articles/stacks_&_queues/3",
            "youtube": "https://youtube.com/watch?v=video82",
            "practice": "https://leetcode.com/problemset/all/?topic=stacks&queues",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-80",
            "title": "Stacks & Queues - Problem 4",
            "article": "https://example.com/articles/stacks_&_queues/4",
            "youtube": "https://youtube.com/watch?v=video83",
            "practice": "https://leetcode.com/problemset/all/?topic=stacks&queues",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-81",
            "title": "Stacks & Queues - Problem 5",
            "article": "https://example.com/articles/stacks_&_queues/5",
            "youtube": "https://youtube.com/watch?v=video84",
            "practice": "https://leetcode.com/problemset/all/?topic=stacks&queues",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-28",
        "title": "Trees",
        "expanded": false,
        "resources": [
          {
            "id": "resource-82",
            "title": "Trees - Problem 3",
            "article": "https://example.com/articles/trees/3",
            "youtube": "https://youtube.com/watch?v=video85",
            "practice": "https://leetcode.com/problemset/all/?topic=trees",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-83",
            "title": "Trees - Problem 4",
            "article": "https://example.com/articles/trees/4",
            "youtube": "https://youtube.com/watch?v=video86",
            "practice": "https://leetcode.com/problemset/all/?topic=trees",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-84",
            "title": "Trees - Problem 5",
            "article": "https://example.com/articles/trees/5",
            "youtube": "https://youtube.com/watch?v=video87",
            "practice": "https://leetcode.com/problemset/all/?topic=trees",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-29",
        "title": "Graphs",
        "expanded": false,
        "resources": [
          {
            "id": "resource-85",
            "title": "Graphs - Problem 3",
            "article": "https://example.com/articles/graphs/3",
            "youtube": "https://youtube.com/watch?v=video88",
            "practice": "https://leetcode.com/problemset/all/?topic=graphs",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-86",
            "title": "Graphs - Problem 4",
            "article": "https://example.com/articles/graphs/4",
            "youtube": "https://youtube.com/watch?v=video89",
            "practice": "https://leetcode.com/problemset/all/?topic=graphs",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-87",
            "title": "Graphs - Problem 5",
            "article": "https://example.com/articles/graphs/5",
            "youtube": "https://youtube.com/watch?v=video90",
            "practice": "https://leetcode.com/problemset/all/?topic=graphs",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-8",
    "title": "Algorithms",
    "topics": [
      {
        "id": "topic-30",
        "title": "Sorting",
        "expanded": false,
        "resources": [
          {
            "id": "resource-88",
            "title": "Sorting - Problem 3",
            "article": "https://example.com/articles/sorting/3",
            "youtube": "https://youtube.com/watch?v=video91",
            "practice": "https://leetcode.com/problemset/all/?topic=sorting",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-89",
            "title": "Sorting - Problem 4",
            "article": "https://example.com/articles/sorting/4",
            "youtube": "https://youtube.com/watch?v=video92",
            "practice": "https://leetcode.com/problemset/all/?topic=sorting",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-90",
            "title": "Sorting - Problem 5",
            "article": "https://example.com/articles/sorting/5",
            "youtube": "https://youtube.com/watch?v=video93",
            "practice": "https://leetcode.com/problemset/all/?topic=sorting",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-31",
        "title": "Searching",
        "expanded": false,
        "resources": [
          {
            "id": "resource-91",
            "title": "Searching - Problem 3",
            "article": "https://example.com/articles/searching/3",
            "youtube": "https://youtube.com/watch?v=video94",
            "practice": "https://leetcode.com/problemset/all/?topic=searching",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-92",
            "title": "Searching - Problem 4",
            "article": "https://example.com/articles/searching/4",
            "youtube": "https://youtube.com/watch?v=video95",
            "practice": "https://leetcode.com/problemset/all/?topic=searching",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-93",
            "title": "Searching - Problem 5",
            "article": "https://example.com/articles/searching/5",
            "youtube": "https://youtube.com/watch?v=video96",
            "practice": "https://leetcode.com/problemset/all/?topic=searching",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-32",
        "title": "Greedy Algorithms",
        "expanded": false,
        "resources": [
          {
            "id": "resource-94",
            "title": "Greedy Algorithms - Problem 3",
            "article": "https://example.com/articles/greedy_algorithms/3",
            "youtube": "https://youtube.com/watch?v=video97",
            "practice": "https://leetcode.com/problemset/all/?topic=greedyalgorithms",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-95",
            "title": "Greedy Algorithms - Problem 4",
            "article": "https://example.com/articles/greedy_algorithms/4",
            "youtube": "https://youtube.com/watch?v=video98",
            "practice": "https://leetcode.com/problemset/all/?topic=greedyalgorithms",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-96",
            "title": "Greedy Algorithms - Problem 5",
            "article": "https://example.com/articles/greedy_algorithms/5",
            "youtube": "https://youtube.com/watch?v=video99",
            "practice": "https://leetcode.com/problemset/all/?topic=greedyalgorithms",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-33",
        "title": "Dynamic Programming",
        "expanded": false,
        "resources": [
          {
            "id": "resource-97",
            "title": "Dynamic Programming - Problem 3",
            "article": "https://example.com/articles/dynamic_programming/3",
            "youtube": "https://youtube.com/watch?v=video100",
            "practice": "https://leetcode.com/problemset/all/?topic=dynamicprogramming",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-98",
            "title": "Dynamic Programming - Problem 4",
            "article": "https://example.com/articles/dynamic_programming/4",
            "youtube": "https://youtube.com/watch?v=video101",
            "practice": "https://leetcode.com/problemset/all/?topic=dynamicprogramming",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-99",
            "title": "Dynamic Programming - Problem 5",
            "article": "https://example.com/articles/dynamic_programming/5",
            "youtube": "https://youtube.com/watch?v=video102",
            "practice": "https://leetcode.com/problemset/all/?topic=dynamicprogramming",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-9",
    "title": "OOP",
    "topics": [
      {
        "id": "topic-34",
        "title": "Encapsulation",
        "expanded": false,
        "resources": [
          {
            "id": "resource-100",
            "title": "Encapsulation - Problem 3",
            "article": "https://example.com/articles/encapsulation/3",
            "youtube": "https://youtube.com/watch?v=video103",
            "practice": "https://leetcode.com/problemset/all/?topic=encapsulation",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-101",
            "title": "Encapsulation - Problem 4",
            "article": "https://example.com/articles/encapsulation/4",
            "youtube": "https://youtube.com/watch?v=video104",
            "practice": "https://leetcode.com/problemset/all/?topic=encapsulation",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-102",
            "title": "Encapsulation - Problem 5",
            "article": "https://example.com/articles/encapsulation/5",
            "youtube": "https://youtube.com/watch?v=video105",
            "practice": "https://leetcode.com/problemset/all/?topic=encapsulation",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-35",
        "title": "Abstraction",
        "expanded": false,
        "resources": [
          {
            "id": "resource-103",
            "title": "Abstraction - Problem 3",
            "article": "https://example.com/articles/abstraction/3",
            "youtube": "https://youtube.com/watch?v=video106",
            "practice": "https://leetcode.com/problemset/all/?topic=abstraction",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-104",
            "title": "Abstraction - Problem 4",
            "article": "https://example.com/articles/abstraction/4",
            "youtube": "https://youtube.com/watch?v=video107",
            "practice": "https://leetcode.com/problemset/all/?topic=abstraction",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-105",
            "title": "Abstraction - Problem 5",
            "article": "https://example.com/articles/abstraction/5",
            "youtube": "https://youtube.com/watch?v=video108",
            "practice": "https://leetcode.com/problemset/all/?topic=abstraction",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-36",
        "title": "Inheritance",
        "expanded": false,
        "resources": [
          {
            "id": "resource-106",
            "title": "Inheritance - Problem 3",
            "article": "https://example.com/articles/inheritance/3",
            "youtube": "https://youtube.com/watch?v=video109",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-107",
            "title": "Inheritance - Problem 4",
            "article": "https://example.com/articles/inheritance/4",
            "youtube": "https://youtube.com/watch?v=video110",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-108",
            "title": "Inheritance - Problem 5",
            "article": "https://example.com/articles/inheritance/5",
            "youtube": "https://youtube.com/watch?v=video111",
            "practice": "https://leetcode.com/problemset/all/?topic=inheritance",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-37",
        "title": "Polymorphism",
        "expanded": false,
        "resources": [
          {
            "id": "resource-109",
            "title": "Polymorphism - Problem 3",
            "article": "https://example.com/articles/polymorphism/3",
            "youtube": "https://youtube.com/watch?v=video112",
            "practice": "https://leetcode.com/problemset/all/?topic=polymorphism",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-110",
            "title": "Polymorphism - Problem 4",
            "article": "https://example.com/articles/polymorphism/4",
            "youtube": "https://youtube.com/watch?v=video113",
            "practice": "https://leetcode.com/problemset/all/?topic=polymorphism",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-111",
            "title": "Polymorphism - Problem 5",
            "article": "https://example.com/articles/polymorphism/5",
            "youtube": "https://youtube.com/watch?v=video114",
            "practice": "https://leetcode.com/problemset/all/?topic=polymorphism",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-10",
    "title": "Web Development",
    "topics": [
      {
        "id": "topic-38",
        "title": "HTML & CSS",
        "expanded": false,
        "resources": [
          {
            "id": "resource-112",
            "title": "HTML & CSS - Problem 3",
            "article": "https://example.com/articles/html_&_css/3",
            "youtube": "https://youtube.com/watch?v=video115",
            "practice": "https://leetcode.com/problemset/all/?topic=html&css",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-113",
            "title": "HTML & CSS - Problem 4",
            "article": "https://example.com/articles/html_&_css/4",
            "youtube": "https://youtube.com/watch?v=video116",
            "practice": "https://leetcode.com/problemset/all/?topic=html&css",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-114",
            "title": "HTML & CSS - Problem 5",
            "article": "https://example.com/articles/html_&_css/5",
            "youtube": "https://youtube.com/watch?v=video117",
            "practice": "https://leetcode.com/problemset/all/?topic=html&css",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-39",
        "title": "JavaScript Basics",
        "expanded": false,
        "resources": [
          {
            "id": "resource-115",
            "title": "JavaScript Basics - Problem 3",
            "article": "https://example.com/articles/javascript_basics/3",
            "youtube": "https://youtube.com/watch?v=video118",
            "practice": "https://leetcode.com/problemset/all/?topic=javascriptbasics",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-116",
            "title": "JavaScript Basics - Problem 4",
            "article": "https://example.com/articles/javascript_basics/4",
            "youtube": "https://youtube.com/watch?v=video119",
            "practice": "https://leetcode.com/problemset/all/?topic=javascriptbasics",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-117",
            "title": "JavaScript Basics - Problem 5",
            "article": "https://example.com/articles/javascript_basics/5",
            "youtube": "https://youtube.com/watch?v=video120",
            "practice": "https://leetcode.com/problemset/all/?topic=javascriptbasics",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-40",
        "title": "React JS",
        "expanded": false,
        "resources": [
          {
            "id": "resource-118",
            "title": "React JS - Problem 3",
            "article": "https://example.com/articles/react_js/3",
            "youtube": "https://youtube.com/watch?v=video121",
            "practice": "https://leetcode.com/problemset/all/?topic=reactjs",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-119",
            "title": "React JS - Problem 4",
            "article": "https://example.com/articles/react_js/4",
            "youtube": "https://youtube.com/watch?v=video122",
            "practice": "https://leetcode.com/problemset/all/?topic=reactjs",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-120",
            "title": "React JS - Problem 5",
            "article": "https://example.com/articles/react_js/5",
            "youtube": "https://youtube.com/watch?v=video123",
            "practice": "https://leetcode.com/problemset/all/?topic=reactjs",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-41",
        "title": "Backend with Node.js",
        "expanded": false,
        "resources": [
          {
            "id": "resource-121",
            "title": "Backend with Node.js - Problem 3",
            "article": "https://example.com/articles/backend_with_node.js/3",
            "youtube": "https://youtube.com/watch?v=video124",
            "practice": "https://leetcode.com/problemset/all/?topic=backendwithnode.js",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-122",
            "title": "Backend with Node.js - Problem 4",
            "article": "https://example.com/articles/backend_with_node.js/4",
            "youtube": "https://youtube.com/watch?v=video125",
            "practice": "https://leetcode.com/problemset/all/?topic=backendwithnode.js",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-123",
            "title": "Backend with Node.js - Problem 5",
            "article": "https://example.com/articles/backend_with_node.js/5",
            "youtube": "https://youtube.com/watch?v=video126",
            "practice": "https://leetcode.com/problemset/all/?topic=backendwithnode.js",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  },
  {
    "id": "subject-11",
    "title": "Machine Learning",
    "topics": [
      {
        "id": "topic-42",
        "title": "Supervised Learning",
        "expanded": false,
        "resources": [
          {
            "id": "resource-124",
            "title": "Supervised Learning - Problem 3",
            "article": "https://example.com/articles/supervised_learning/3",
            "youtube": "https://youtube.com/watch?v=video127",
            "practice": "https://leetcode.com/problemset/all/?topic=supervisedlearning",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-125",
            "title": "Supervised Learning - Problem 4",
            "article": "https://example.com/articles/supervised_learning/4",
            "youtube": "https://youtube.com/watch?v=video128",
            "practice": "https://leetcode.com/problemset/all/?topic=supervisedlearning",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-126",
            "title": "Supervised Learning - Problem 5",
            "article": "https://example.com/articles/supervised_learning/5",
            "youtube": "https://youtube.com/watch?v=video129",
            "practice": "https://leetcode.com/problemset/all/?topic=supervisedlearning",
            "difficulty": 2,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-43",
        "title": "Unsupervised Learning",
        "expanded": false,
        "resources": [
          {
            "id": "resource-127",
            "title": "Unsupervised Learning - Problem 3",
            "article": "https://example.com/articles/unsupervised_learning/3",
            "youtube": "https://youtube.com/watch?v=video130",
            "practice": "https://leetcode.com/problemset/all/?topic=unsupervisedlearning",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-128",
            "title": "Unsupervised Learning - Problem 4",
            "article": "https://example.com/articles/unsupervised_learning/4",
            "youtube": "https://youtube.com/watch?v=video131",
            "practice": "https://leetcode.com/problemset/all/?topic=unsupervisedlearning",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-129",
            "title": "Unsupervised Learning - Problem 5",
            "article": "https://example.com/articles/unsupervised_learning/5",
            "youtube": "https://youtube.com/watch?v=video132",
            "practice": "https://leetcode.com/problemset/all/?topic=unsupervisedlearning",
            "difficulty": 3,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-44",
        "title": "Model Evaluation",
        "expanded": false,
        "resources": [
          {
            "id": "resource-130",
            "title": "Model Evaluation - Problem 3",
            "article": "https://example.com/articles/model_evaluation/3",
            "youtube": "https://youtube.com/watch?v=video133",
            "practice": "https://leetcode.com/problemset/all/?topic=modelevaluation",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-131",
            "title": "Model Evaluation - Problem 4",
            "article": "https://example.com/articles/model_evaluation/4",
            "youtube": "https://youtube.com/watch?v=video134",
            "practice": "https://leetcode.com/problemset/all/?topic=modelevaluation",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-132",
            "title": "Model Evaluation - Problem 5",
            "article": "https://example.com/articles/model_evaluation/5",
            "youtube": "https://youtube.com/watch?v=video135",
            "practice": "https://leetcode.com/problemset/all/?topic=modelevaluation",
            "difficulty": 4,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      },
      {
        "id": "topic-45",
        "title": "Overfitting & Underfitting",
        "expanded": false,
        "resources": [
          {
            "id": "resource-133",
            "title": "Overfitting & Underfitting - Problem 3",
            "article": "https://example.com/articles/overfitting_&_underfitting/3",
            "youtube": "https://youtube.com/watch?v=video136",
            "practice": "https://leetcode.com/problemset/all/?topic=overfitting&underfitting",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-134",
            "title": "Overfitting & Underfitting - Problem 4",
            "article": "https://example.com/articles/overfitting_&_underfitting/4",
            "youtube": "https://youtube.com/watch?v=video137",
            "practice": "https://leetcode.com/problemset/all/?topic=overfitting&underfitting",
            "difficulty": 5,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          },
          {
            "id": "resource-135",
            "title": "Overfitting & Underfitting - Problem 5",
            "article": "https://example.com/articles/overfitting_&_underfitting/5",
            "youtube": "https://youtube.com/watch?v=video138",
            "practice": "https://leetcode.com/problemset/all/?topic=overfitting&underfitting",
            "difficulty": 1,
            "completed": false,
            "markedForRevision": false,
            "notes": ""
          }
        ]
      }
    ],
    "expanded": false
  }
];

export default interviewData;